#!/usr/bin/env python3
"""Autonomous offline security agent: triage the statement, brief the model, run a
bounded tool loop, verify the deliverable, always leave a valid artifact, exit 0."""

import json
import os
import re
import signal
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from acpagent import brief, ctf_gate, forensic_seed, hardenfix, kv_seed, kv_verify, oracle, prompts, safefix, sqlfix, tools, vulnreport  # noqa: E402
from acpagent import spec as specmod  # noqa: E402
from acpagent.llm import (LLM, BudgetExceeded, ContextTooLong, ToolCall, ToolsUnsupported,  # noqa: E402
                          estimate_tokens, parse_arguments)

# ---- budgets -----------------------------------------------------------------------------
# Published limits are 120s for trivial tasks and 600s for everything else. A run that is
# not yet solved scores 0 whether it stops voluntarily or gets killed, so the soft deadline
# is generous but leaves margin for the finaliser and for slower hidden limits.
SOFT_DEADLINE_SEC = float(os.environ.get("LOCAL_AGENT_DEADLINE_SEC") or 520)
HARD_GRACE_SEC = 12
TOKEN_BUDGET = int(os.environ.get("LOCAL_AGENT_TOKEN_BUDGET") or 140000)
MAX_ROUNDS = int(os.environ.get("LOCAL_AGENT_MAX_ROUNDS") or 40)
# Per-kind caps: an audit report is merged with the scan anyway, so a weak model should
# not spend the whole budget polishing it; code fixes and CTFs get more room.
ROUND_CAPS = {"json_report": 16, "kv_report": 22, "ctf": 26, "code_fix": 32, "generic": 22, "exact": 6}
MAX_CORRECTIONS = 8
HISTORY_CHAR_CAP = int(os.environ.get("LOCAL_AGENT_HISTORY_CHARS") or 56000)
KEEP_RECENT_ROUNDS = 3
TEST_TIMEOUT_SEC = 170

WORKDIR_CANDIDATES = ("/app", "/workspace", "/srv/app", "/data", "/opt/app", "/home/user/app")

START_TS = time.monotonic()


def log(msg: str) -> None:
    print(f"[agent] {msg}", flush=True)


def _holds_task(p: Path) -> bool:
    """True when a directory carries task content, not just the image's own virtualenv."""
    try:
        for child in p.iterdir():
            if child.name.startswith(".") or child.name in ("venv", "node_modules", "__pycache__"):
                continue
            return True
    except OSError:
        return True  # unreadable: assume it counts rather than skipping the real task
    return False


def pick_workdir() -> Path:
    forced = os.environ.get("AGENT_FORCE_WORKDIR")
    if forced:
        return Path(forced)
    raw = os.environ.get("LOCAL_AGENT_WORKDIR")
    if raw and Path(raw).is_dir() and not (Path(raw) / "agent.py").is_file():
        if _holds_task(Path(raw)):
            return Path(raw)
    for cand in WORKDIR_CANDIDATES:
        p = Path(cand)
        if p.is_dir() and _holds_task(p):
            return p
    return Path(raw) if raw else Path.cwd()


class State:
    def __init__(self):
        self.workdir = Path("/app")
        self.spec = None
        self.instruction = ""
        self.llm = None
        self.brief = {"text": "", "hotspots": [], "routes": [], "flags": []}
        self.snapshot = {}
        self.servers = []
        self.seed = None
        self.seed_conf = {}     # key -> 'high' | 'low' (profile seed only)
        self.seed_partial = None  # high-confidence values for some keys only
        self.report_seeded = 0    # findings in the draft report written before the model
        self.report_gaps = []     # weaknesses our own audit found in that draft
        self.final_text = ""
        self.finalized = False
        self.deadline_ts = START_TS + SOFT_DEADLINE_SEC
        self.deliverable_mtime = None
        self.tests_passed = False
        self.test_baseline = None   # (ok, failing test ids) before any change of ours
        self.critical_nudged = False
        self.mechanical_notes = []
        self.seen_flags = []  # flag-shaped strings observed in tool outputs (ctf)
        self.call_history = []  # (tool, args) of every executed call, for retry notes
        self.kv_nudges = 0
        self.retry_note = ""


# ---- text protocol recovery ----------------------------------------------------------------

_TC_TAG_RE = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.S)
_TC_FENCE_RE = re.compile(r"```(?:json|tool_call|tool)?\s*(\{.*?\})\s*```", re.S)
_CODE_FENCE_RE = re.compile(r"```(bash|sh|shell|console|zsh)?\s*\n(.*?)```", re.S)


def _as_call(data, idx):
    if not isinstance(data, dict):
        return None
    name = data.get("name") or data.get("tool") or data.get("tool_name") or data.get("function")
    args = data.get("arguments", data.get("args", data.get("parameters", data.get("input"))))
    if isinstance(name, dict):
        args = name.get("arguments", name.get("parameters", args))
        name = name.get("name")
    if not isinstance(name, str):
        return None
    canonical = tools.canonical_name(name)
    if canonical not in tools.TOOL_NAMES:
        return None
    if isinstance(args, str):
        args = parse_arguments(args)
    if not isinstance(args, dict):
        args = {k: v for k, v in data.items() if k not in ("name", "tool", "tool_name", "function", "type", "id")}
    return ToolCall(f"recovered_{idx}", canonical, args, recovered=True)


def recover_calls(text: str):
    """Tool calls a model wrote into its message instead of the tool_calls field."""
    if not text:
        return []
    calls = []
    for rx in (_TC_TAG_RE, _TC_FENCE_RE):
        for m in rx.finditer(text):
            try:
                data = json.loads(m.group(1))
            except ValueError:
                try:
                    data = json.loads(re.sub(r",\s*([}\]])", r"\1", m.group(1)))
                except ValueError:
                    continue
            c = _as_call(data, len(calls))
            if c:
                calls.append(c)
        if calls:
            return calls
    stripped = text.strip()
    if stripped.startswith("{") and stripped.endswith("}"):
        data = oracle.load_json_lenient(stripped)
        c = _as_call(data, 0)
        if c:
            return [c]
    # A lone shell fence with almost no prose around it is a command the model meant to run.
    fences = _CODE_FENCE_RE.findall(text)
    if len(fences) == 1 and fences[0][0]:
        outside = _CODE_FENCE_RE.sub("", text).strip()
        if len(outside) < 240 and "DONE" not in outside.upper():
            cmd = fences[0][1].strip()
            if cmd and len(cmd) < 4000:
                return [ToolCall("recovered_sh", "bash", {"command": cmd}, recovered=True)]
    return []


# ---- history management ----------------------------------------------------------------------

def _msg_chars(m) -> int:
    n = len(m.get("content") or "")
    for tc in m.get("tool_calls") or ():
        n += len(json.dumps(tc.get("function", {})))
    return n


def trim_history(messages, cap=HISTORY_CHAR_CAP, keep_recent=KEEP_RECENT_ROUNDS, aggressive=False):
    """Elide old tool outputs (and, if needed, drop whole old rounds) to fit under cap."""
    total = sum(_msg_chars(m) for m in messages)
    if total <= cap and not aggressive:
        return messages
    # index of assistant turns
    assistant_idx = [i for i, m in enumerate(messages) if m.get("role") == "assistant"]
    if len(assistant_idx) <= 1:
        return messages
    cutoff = assistant_idx[-keep_recent] if len(assistant_idx) >= keep_recent else assistant_idx[0]
    out = []
    for i, m in enumerate(messages):
        if i < cutoff and i >= 2 and m.get("role") in ("tool", "user") and len(m.get("content") or "") > 400:
            content = m["content"]
            m = dict(m)
            m["content"] = content[:300] + f"\n... [{len(content) - 300} chars of earlier output elided]"
        out.append(m)
    total = sum(_msg_chars(m) for m in out)
    if total <= cap and not aggressive:
        return out
    # Drop whole old rounds (assistant + its tool replies) but keep system + task + last rounds.
    prefix = out[:2]
    rounds = []
    for m in out[2:]:
        if m.get("role") == "assistant" or not rounds:
            rounds.append([m])
        else:
            rounds[-1].append(m)
    dropped = 0
    while len(rounds) > max(2, keep_recent - 1) and (aggressive or sum(_msg_chars(m) for r in rounds for m in r) + sum(_msg_chars(m) for m in prefix) > cap):
        rounds.pop(0)
        dropped += 1
        aggressive = False
    note = {"role": "user", "content": f"[{dropped} earlier round(s) were removed to save context. Do not repeat exploration you already did; the files you edited are still edited.]"} if dropped else None
    result = prefix + ([note] if note else []) + [m for r in rounds for m in r]
    # A tool message must follow an assistant message with tool_calls; drop orphans.
    cleaned = []
    for m in result:
        if m.get("role") == "tool":
            prev = cleaned[-1] if cleaned else None
            if not prev or prev.get("role") not in ("assistant", "tool"):
                continue
        cleaned.append(m)
    return cleaned


# ---- prompts -------------------------------------------------------------------------------

def system_prompt(st: State, text_protocol: bool) -> str:
    sp = st.spec
    base = prompts.BASE.format(workdir=st.workdir)
    if sp.kind == "json_report":
        shape = prompts.report_shape(sp.json_root, sp.json_fields)
        if sp.report_format == "text":
            shape = ("a written report (Markdown): one '## <title> [severity]' section per finding with the "
                     "category (CWE), location (file:line, function, endpoint), evidence (quoted code + payload), "
                     "impact and recommendation")
        block = prompts.VULN_REPORT.format(path=sp.deliverable, shape=shape)
        if sp.also_fix:
            block = block.replace("Do NOT modify application code.",
                                  "The task ALSO asks you to fix the issues: after writing the report, edit the "
                                  "vulnerable code with str_replace (parameterized queries, no shell=True, path "
                                  "checks) without changing normal behaviour, and run the project's tests if any.")
    elif sp.kind == "code_fix":
        hint = f" (`{sp.test_cmd}`)" if sp.test_cmd else ""
        block = prompts.CODE_FIX.format(test_hint=hint)
    elif sp.kind == "kv_report":
        example = "\n".join(f"{k}=<value>" for k in sp.keys)
        fmt = prompts.KV_FORMAT.format(path=sp.deliverable, n=len(sp.keys), keys=", ".join(sp.keys), example=example)
        block = prompts.FORENSICS.format(format_block=fmt)
    elif sp.kind == "ctf":
        flag_hint = f"The flag format is {sp.flag_prefix}...}}." if sp.flag_prefix else "Flags usually look like TAG{...}."
        if sp.deliverable:
            dblock = f"Deliverable: write ONLY the flag (nothing else) to {sp.deliverable} with write_file, then reply DONE followed by the flag."
        else:
            dblock = "When you have the flag, reply exactly: DONE FLAG: <the flag> (no tool call). If the task names an output file, write the flag there too."
        block = prompts.CTF.format(flag_hint=flag_hint, deliverable_block=dblock)
    else:
        if sp.deliverable:
            dblock = f"Deliverable: {sp.deliverable} (write it with write_file, then reply DONE)."
        else:
            dblock = "If the task names an output file, write it; otherwise put the final answer on the last line of your DONE reply."
        block = prompts.GENERIC.format(deliverable_block=dblock)
    out = base + block
    if text_protocol:
        out += prompts.TEXT_PROTOCOL
    return out


def user_prompt(st: State) -> str:
    parts = [f"TASK:\n{st.instruction.strip()}"]
    if st.brief.get("text"):
        parts.append(f"CONTEXT GATHERED AUTOMATICALLY (verify before relying on it):\n{st.brief['text']}")
    if st.retry_note:
        parts.append(st.retry_note)
    if st.mechanical_notes:
        parts.append("ALREADY FIXED MECHANICALLY (tests pass with these changes; do not redo them):\n"
                     + "\n".join(f"- {n}" for n in st.mechanical_notes))
    if st.seed:
        def _tag(k):
            c = st.seed_conf.get(k)
            return "" if not c else ("   <- matches the task's definition literally" if c == "high" else "   <- a default reading; verify this one")
        parts.append("PRELIMINARY AUTOMATED ANSWER (computed by code from the evidence; already written to the deliverable; "
                     "each value cites its source line below — confirm every value against the task's definition, correct "
                     "only what contradicts it):\n" + "\n".join(f"{k}={v}{_tag(k)}" for k, v in st.seed.items() if not k.startswith("_"))
                     + ("\n" + st.seed["_detail"] if st.seed.get("_detail") else ""))
    elif st.seed_partial:
        parts.append("PARTIAL PRELIMINARY VALUES (computed by code; only these keys could be derived mechanically — the "
                     "remaining keys are yours to derive from the profiles):\n"
                     + "\n".join(f"{k}={v}" for k, v in st.seed_partial.items() if not k.startswith("_"))
                     + ("\n" + st.seed_partial["_detail"] if st.seed_partial.get("_detail") else ""))
    sp = st.spec
    if st.report_seeded:
        note = (f"A COMPLETE DRAFT REPORT has already been written to {sp.deliverable} by an automated scan of the "
                f"code ({st.report_seeded} findings, most severe first). Read it FIRST with read_file. Your job is to "
                "improve it, not to start over:\n"
                "- verify each finding against the real code and correct anything inaccurate;\n"
                "- ADD the vulnerabilities a pattern scan cannot see: missing authentication/authorization (IDOR), "
                "mass assignment, information disclosure in responses or logs, insecure defaults, weak session or "
                "token handling, business-logic flaws;\n"
                "- never delete a finding that is correct, and keep the same JSON shape.")
        if st.report_gaps:
            note += "\nOur own audit of the draft flagged: " + "; ".join(st.report_gaps)
        parts.append(note)
    if sp.kind == "kv_report" and sp.deliverable:
        parts.append(f"REMINDER: the graded file is {sp.deliverable} with exactly these keys: {', '.join(sp.keys)}.")
    elif sp.deliverable:
        parts.append(f"REMINDER: the graded file is {sp.deliverable}.")
    return "\n\n".join(parts)


_QUOTED_RE = re.compile(r"""['"]([^'"\n]{6,80})['"]""")
_PROFILE_WORDS = ("suspicious", "profile", "first success", "failed before", "accepted (successful", "→ utc", "severe",
                  "first request", "last request", "top:", "rare", "per client", "per source", "answered 2xx")


def _profile_phrase(command: str, brief_text: str):
    """A quoted search phrase that exists only in the briefing (profile wording), if any."""
    if "grep" not in command and "rg " not in command and "awk" not in command:
        return None
    low_brief = brief_text.lower()
    for phrase in _QUOTED_RE.findall(command):
        lp = phrase.lower().strip()
        if len(lp) < 6 or any(ch in lp for ch in "\\[]()|*^$"):
            continue
        if lp in low_brief and any(w in lp for w in _PROFILE_WORDS):
            return phrase
    return None


# ---- oracle dispatch -----------------------------------------------------------------------

def _mtime(path):
    try:
        return os.stat(path).st_mtime_ns
    except OSError:
        return None


def check_done(st: State, final_text: str):
    """Return (ok, why). Runs the kind-specific oracle."""
    sp = st.spec
    try:
        if sp.kind == "exact":
            for pth, content in (sp.exact_files or [(sp.deliverable, sp.exact_content)]):
                ok, why = oracle.check_exact(pth, content)
                if not ok:
                    return ok, why
            return True, ""
        if sp.kind == "json_report" and sp.report_format == "text":
            ok, why = oracle.check_text_report(sp.deliverable)
            if not ok and final_text and len(final_text) > 300 and oracle._VULN_WORDS.search(final_text):
                body = re.sub(r"^DONE[:.\s-]*", "", final_text.strip(), flags=re.I)
                oracle.write_text(sp.deliverable, body)
                log("salvaged the text report from the reply")
                return oracle.check_text_report(sp.deliverable)
            return ok, why
        if sp.kind == "json_report":
            ok, why = oracle.check_json_report(sp.deliverable, sp.json_root, sp.json_fields)
            if not ok and final_text and len(final_text) > 200:
                obj = oracle.load_json_lenient(final_text)
                report, findings = oracle.normalise_report(obj, sp.json_root, sp.json_fields) if obj is not None else (None, None)
                if report is not None and findings:
                    oracle.write_text(sp.deliverable, json.dumps(report, ensure_ascii=False, indent=2))
                    log(f"salvaged a JSON report with {len(findings)} finding(s) from the reply")
                    return oracle.check_json_report(sp.deliverable, sp.json_root, sp.json_fields)
            return ok, why
        if sp.kind == "kv_report":
            ok, why = oracle.check_kv(sp.deliverable, sp.keys)
            if ok and st.kv_nudges < 2:
                found = oracle.parse_kv_text(oracle.read_text(sp.deliverable), sp.keys)
                problems = []
                bad = oracle.kv_plausibility(found, sp.evidence_dir or str(st.workdir))
                if bad:
                    problems.append(f"these values do not occur anywhere in the evidence files: {bad} "
                                    "(entity values must be copied verbatim from the records)")
                try:
                    problems += oracle.kv_constraints(found, sp.keys, sp.evidence_dir or str(st.workdir), st.instruction)
                except Exception as exc:  # noqa: BLE001
                    log(f"constraint check failed: {exc}")
                if problems:
                    st.kv_nudges += 1
                    return False, ("the file is well-formed but some values look wrong:\n- " + "\n- ".join(problems) +
                                   "\nRe-check them against the evidence and the task's definitions, correct the file "
                                   "(if you are certain a value is right, write the file again unchanged) and reply DONE.")
            if not ok and final_text:
                found = oracle.salvage_kv_from_text(final_text, sp.keys)
                if found and not any(v.lower() in oracle.PLACEHOLDERS for v in found.values()):
                    oracle.write_kv(sp.deliverable, found, sp.keys)
                    log("salvaged key=value answer from the reply")
                    return oracle.check_kv(sp.deliverable, sp.keys)
            return ok, why
        if sp.kind == "ctf":
            if sp.deliverable:
                ok, why = oracle.check_flag_file(sp.deliverable, sp.flag_prefix)
                if not ok and final_text:
                    flag = oracle.extract_flag(final_text, sp.flag_prefix)
                    if flag:
                        oracle.write_text(sp.deliverable, flag)
                        log(f"salvaged flag from the reply: {flag}")
                        return True, ""
                return ok, why
            flag = oracle.extract_flag(final_text or "", sp.flag_prefix)
            if flag:
                return True, ""
            return (bool(final_text and final_text.strip()), "no flag found in the reply; reply DONE FLAG: <flag>")
        if sp.kind == "code_fix":
            return check_code_fix(st)
        if sp.deliverable:
            return oracle.check_nonempty(sp.deliverable)
        return True, ""
    except Exception as exc:  # noqa: BLE001
        log(f"oracle raised: {exc}")
        return True, ""


def check_code_fix(st: State):
    changed = oracle.changed_files(st.workdir, st.snapshot)
    if not changed:
        return False, ("no source file has been modified yet. Read the code, find the vulnerability the task "
                       "describes and edit the file with str_replace.")
    errs = oracle.compile_errors(changed)
    if errs:
        return False, "syntax errors in edited files:\n" + "\n".join(errs)[:1500]
    remaining = st.deadline_ts - time.monotonic()
    if st.servers and remaining > 40:
        problems = oracle.restart_servers(st.servers, log=log)
        if problems:
            return False, "\n".join(problems)[:2500]
    if st.spec.test_cmd and remaining > 30:
        ok, out = oracle.run_tests(st.spec.test_cmd, st.workdir, min(TEST_TIMEOUT_SEC, max(20, remaining - 15)))
        if ok is False:
            why = f"the test command `{st.spec.test_cmd}` fails:\n{tools.truncate(out, 2500)}"
            if "500" in out or "Internal Server Error" in out or "Connection" in out:
                why += oracle.server_log_tail(st.servers)
            return False, why
        if ok is None:
            log("test command produced no usable result; not blocking on it")
        else:
            st.tests_passed = True
    if st.spec.deliverable:
        ok, why = oracle.check_nonempty(st.spec.deliverable)
        if not ok:
            return False, f"the task also asks for a written file: {why}"
    if not st.critical_nudged:
        crit = [h for h in oracle.remaining_critical(st.workdir) if h["label"].startswith("SQL") or "command" in h["label"].lower()]
        if crit:
            st.critical_nudged = True
            listing = brief.format_hotspots(crit[:6])
            return False, ("tests pass, but these lines still build SQL/shell commands from input — if any of them is "
                           "reachable with user data, fix it too; if they are all false positives reply DONE again:\n" + listing)
    return True, ""


_DECOY_RE = re.compile(r"fake|decoy|example|sample|not_the|placeholder|test_flag|dummy|xxx|redacted|your_flag|flag_here", re.I)


def _clean_flag(value: str, prefix: str) -> bool:
    """A candidate worth trusting without the model: right prefix, a body made of
    ordinary flag characters, and no decoy wording."""
    if prefix and not value.startswith(prefix):
        return False
    body = value[value.find("{") + 1:-1]
    if len(body) < 3 or _DECOY_RE.search(body):
        return False
    return all(ch.isalnum() or ch in "_-!?@#$.,:+=/ " for ch in body)


# ---- deterministic code fix ---------------------------------------------------------------------

_FAILED_RE = re.compile(r"^(?:FAILED|ERROR)\s+(\S+)", re.M)


def _failing_tests(output: str):
    """Identities of the tests that failed, so a pre-existing failure can be told apart
    from one our change introduced."""
    return set(_FAILED_RE.findall(output or ""))


def _control_run(st: State, module, originals: dict, failed_with_fix: set):
    """Is this failure ours, or was the suite failing anyway?

    Asked only after a fix has failed the tests, and asked by putting the original code
    back and running the same suite again. Doing it this way rather than measuring a
    baseline up front matters: these suites create data, so running them an extra time
    when nothing is wrong would make the second run fail on its own leftovers. The
    control runs under exactly the conditions the failure did.

    Returns True when the fix introduced no failure of its own and has been put back."""
    if not st.spec.test_cmd or not originals:
        return False
    try:
        fixed = {path: Path(path).read_text(encoding="utf-8", errors="replace") for path in originals}
    except OSError:
        return False
    module.revert(originals)
    if st.servers:
        oracle.restart_servers(st.servers, log=lambda *_a, **_k: None)
    ok, out = oracle.run_tests(st.spec.test_cmd, st.workdir,
                               min(TEST_TIMEOUT_SEC, max(20, st.deadline_ts - time.monotonic() - 30)))
    if ok is not False:
        return False  # the original code passes: the failure really is ours
    introduced = failed_with_fix - _failing_tests(out)
    if introduced:
        return False
    for path, text in fixed.items():
        try:
            Path(path).write_text(text, encoding="utf-8")
        except OSError:
            return False
    if st.servers:
        oracle.restart_servers(st.servers, log=lambda *_a, **_k: None)
    log(f"the same {len(failed_with_fix)} test(s) fail without our change too "
        f"(the environment, not the fix); keeping the rewrite")
    return True


def _verify_stage(st: State, label: str, originals: dict, notes: list, module) -> bool:
    """Keep a mechanical rewrite only if the code compiles, the app restarts and the
    tests pass; otherwise revert it (and put the server back)."""
    if not originals:
        return False
    for n in notes:
        log(f"{label}: {n}")
    ok = True
    errs = oracle.compile_errors([Path(p) for p in originals])
    if errs:
        log(f"{label} produced syntax errors; reverting: {errs[0][:200]}")
        ok = False
    if ok and st.servers:
        problems = oracle.restart_servers(st.servers, log=log)
        if problems:
            log(f"server failed after {label}; reverting: {problems[0][:200]}")
            ok = False
    if ok and st.spec.test_cmd:
        tok, out = oracle.run_tests(st.spec.test_cmd, st.workdir,
                                    min(TEST_TIMEOUT_SEC, max(20, st.deadline_ts - time.monotonic() - 30)))
        if tok is False:
            now_failing = _failing_tests(out)
            if now_failing and _control_run(st, module, originals, now_failing):
                return True
            log(f"tests fail after {label}; reverting: "
                + (", ".join(sorted(now_failing)[:3]) if now_failing else out[-300:]))
            ok = False
        elif tok is None:
            log(f"tests produced no usable result after {label}; keeping the rewrite (it compiles)")
    if not ok:
        module.revert(originals)
        if st.servers:
            oracle.restart_servers(st.servers, log=log)
        return False
    return True


def mechanical_sql_fix(st: State) -> bool:
    """Apply the mechanical rewrites (SQL parameterization, then command/config
    hardening), each verified by the project's tests. Returns True when nothing risky
    is left and the task is finished."""
    kept = []
    originals, notes = sqlfix.apply(st.workdir)
    if _verify_stage(st, "sqlfix", originals, notes, sqlfix):
        kept.extend(notes)
    originals, notes = safefix.apply(st.workdir)
    if _verify_stage(st, "safefix", originals, notes, safefix):
        kept.extend(notes)
    # Path traversal / signature checks: try the strict containment check first; if the
    # project's tests reject it (they exercise sub-directories, say), fall back to the
    # gentler rewrite. _verify_stage has already reverted before the second attempt.
    originals, notes = hardenfix.apply(st.workdir)
    if _verify_stage(st, "hardenfix", originals, notes, hardenfix):
        kept.extend(notes)
    elif originals:
        originals, notes = hardenfix.apply_basename(st.workdir)
        if _verify_stage(st, "hardenfix(basename)", originals, notes, hardenfix):
            kept.extend(notes)
    if not kept:
        return False
    st.tests_passed = True
    remaining = [h for h in brief.scan_hotspots(st.workdir)
                 if h["severity"] in ("critical", "high") and h["category"] not in brief.AUDIT_ONLY_CATEGORIES]
    if st.spec.deliverable:
        remaining.append({"file": st.spec.deliverable, "line": 0, "label": "deliverable still to be written"})
    if not remaining:
        log("code_fix solved deterministically: mechanical fixes applied, tests pass, no risky patterns left (0 tokens)")
        return True
    st.mechanical_notes = kept
    log(f"mechanical fixes kept; {len(remaining)} risky pattern(s) remain for the model")
    return False


# ---- main loop -----------------------------------------------------------------------------

def run_loop(st: State):
    llm = st.llm
    sp = st.spec
    text_mode = not llm.supports_tools
    messages = [
        {"role": "system", "content": system_prompt(st, text_mode)},
        {"role": "user", "content": user_prompt(st)},
    ]
    st.deliverable_mtime = _mtime(sp.deliverable) if sp.deliverable else None
    rounds = 0
    corrections = 0
    empty_streak = 0
    last_sig = None
    repeat = 0
    context_retries = 0
    final_text = ""
    edit_counts = {}
    sig_counts = {}      # (call, result) signature -> occurrences anywhere in the run
    error_streak = 0     # consecutive tool results that were errors
    no_call_rounds = 0   # rounds without any tool call while tools were advertised
    ever_called = False
    max_rounds = min(MAX_ROUNDS, ROUND_CAPS.get(sp.kind, MAX_ROUNDS))
    while rounds < max_rounds:
        if llm.exhausted():
            log("budget exhausted; leaving the loop")
            break
        messages = trim_history(messages)
        try:
            # The first turn is always exploration (a short tool call); a long first reply
            # only happens when the model answers in prose because tools never reached it.
            res = llm.chat(messages, tools=None if text_mode else tools.TOOL_SCHEMAS,
                           max_tokens=2048 if rounds == 0 else None)
        except ToolsUnsupported:
            text_mode = True
            messages[0] = {"role": "system", "content": system_prompt(st, True)}
            continue
        except ContextTooLong as exc:
            context_retries += 1
            log(f"context too long ({exc}); trimming harder ({context_retries})")
            if context_retries > 3:
                break
            messages = trim_history(messages, cap=HISTORY_CHAR_CAP // 2, keep_recent=2, aggressive=True)
            if context_retries >= 2:
                if len(messages) > 1 and len(messages[1].get("content") or "") > 6000:
                    messages[1] = dict(messages[1])
                    messages[1]["content"] = messages[1]["content"][:6000] + "\n... (context shortened)"
                # Even the most recent outputs must shrink when the window is this small.
                for i in range(2, len(messages)):
                    m = messages[i]
                    if m.get("role") in ("tool", "user") and len(m.get("content") or "") > 1500:
                        messages[i] = dict(m)
                        messages[i]["content"] = m["content"][:1500] + "\n... [truncated to fit the context window]"
            continue
        except BudgetExceeded as exc:
            log(f"stopping: {exc}")
            break
        rounds += 1
        text = (res.text or "").strip()
        calls = list(res.tool_calls)
        if not calls:
            calls = recover_calls(text)
            if calls:
                log(f"recovered {len(calls)} tool call(s) from text")
        log(f"round {rounds}: {len(calls)} call(s), {len(text)} chars, finish={res.finish}, tokens={llm.tokens_used}")
        if calls:
            ever_called = True
        elif not text_mode and not ever_called:
            no_call_rounds += 1
            # One prose-only reply that does not finish the task is enough evidence that
            # the tool schemas are not reaching the model (or it will not use them).
            if no_call_rounds >= 1 and not check_done(st, text)[0]:
                # The server accepted the tool schemas but the model never calls them:
                # most likely they were silently ignored. Switch to the text protocol.
                text_mode = True
                llm.supports_tools = False
                messages[0] = {"role": "system", "content": system_prompt(st, True)}
                log("no tool calls in two rounds; switching to the text protocol")
                messages.append({"role": "assistant", "content": text or "(no reply)"})
                messages.append({"role": "user", "content": "Use the tool call format described in the system prompt to inspect files and act."})
                continue
        if not calls:
            if text:
                final_text = text
            if not text:
                empty_streak += 1
                if empty_streak >= 3:
                    log("model returned nothing three times; leaving the loop")
                    break
                messages.append({"role": "user", "content": prompts.NUDGE_NO_TOOL})
                continue
            empty_streak = 0
            ok, why = check_done(st, text)
            if ok:
                log("deliverable verified; done")
                st.final_text = text
                return
            corrections += 1
            log(f"not done ({corrections}): {why[:200]}")
            if corrections > MAX_CORRECTIONS:
                break
            messages.append({"role": "assistant", "content": text})
            messages.append({"role": "user", "content": prompts.NOT_DONE.format(why=why)})
            if corrections >= 2:
                llm.temperature = 0.3
            continue
        empty_streak = 0
        native = not text_mode and not any(c.recovered for c in calls)
        if native:
            messages.append({
                "role": "assistant",
                "content": text or None,
                "tool_calls": [
                    {"id": c.id, "type": "function",
                     "function": {"name": c.name, "arguments": json.dumps(c.arguments, ensure_ascii=False)}}
                    for c in calls
                ],
            })
        else:
            messages.append({"role": "assistant", "content": text or json.dumps({"name": calls[0].name, "arguments": calls[0].arguments})})
        # Many calls in one round must share the output budget, or one round alone can
        # overflow a small context window.
        per_call_cap = max(1800, min(tools.MAX_TOOL_OUTPUT_CHARS, 24000 // max(1, len(calls))))
        for c in calls:
            if st.spec.no_modify and c.name in ("write_file", "str_replace"):
                target = os.path.abspath(str(tools.resolve(str(c.arguments.get("path", "")), st.workdir)))
                inside = target.startswith(os.path.abspath(str(st.workdir)) + os.sep)
                if inside and (not sp.deliverable or target != os.path.abspath(sp.deliverable)):
                    result = (f"[error] this task forbids modifying application files; write only the deliverable "
                              f"{sp.deliverable or ''} (helper scripts can go under /tmp)")
                else:
                    result = tools.dispatch(c.name, c.arguments, st.workdir)
            elif c.name in ("write_file", "str_replace"):
                key = (c.name, json.dumps(c.arguments, sort_keys=True, ensure_ascii=False))
                edit_counts[key] = edit_counts.get(key, 0) + 1
                if edit_counts[key] > 2:
                    result = ("[error] You already applied this exact edit twice and the problem is still there. "
                              "Do something different: read_file the whole function, then rewrite it correctly "
                              "(complete, properly indented) with write_file or a larger str_replace.")
                else:
                    result = tools.dispatch(c.name, c.arguments, st.workdir)
            else:
                result = tools.dispatch(c.name, c.arguments, st.workdir)
            if len(calls) > 1 and len(result) > per_call_cap:
                result = tools.truncate(result, per_call_cap)
            if sp.kind == "ctf":
                seen = oracle.extract_flag(result, sp.flag_prefix)
                if seen and (not sp.flag_prefix or seen.startswith(sp.flag_prefix)) and seen not in st.seen_flags:
                    st.seen_flags.append(seen)
                    log(f"flag-shaped string seen in tool output: {seen}")
            if c.name == "bash" and sp.kind in ("kv_report", "generic") and (result.startswith("[exit 1]") or result.startswith("[exit 2]")):
                phrase = _profile_phrase(str(c.arguments.get("command", "")), st.brief.get("text", ""))
                if phrase:
                    result += (f"\n[hint] '{phrase}' is wording from the automatically computed profile in your context, "
                               "not text inside the evidence files. The profile's numbers, lines and '→ UTC' values were "
                               "computed by code from the whole file — use them directly instead of searching for them.")
            preview = result.replace("\n", " ")[:160]
            st.call_history.append((c.name, json.dumps(c.arguments, ensure_ascii=False)[:200]))
            log(f"  {c.name}({json.dumps(c.arguments, ensure_ascii=False)[:150]}) -> {preview}")
            if native:
                messages.append({"role": "tool", "tool_call_id": c.id, "content": result})
            else:
                messages.append({"role": "user", "content": f"<tool_response>\n{result}\n</tool_response>"})
            sig = (c.name, json.dumps(c.arguments, sort_keys=True), result[:400])
            if sig == last_sig:
                repeat += 1
            else:
                repeat = 0
            last_sig = sig
            sig_counts[sig] = sig_counts.get(sig, 0) + 1
            failed = result.startswith("[error]") or result.startswith("[exit ") and not result.startswith("[exit 0]")
            error_streak = error_streak + 1 if failed else 0
        worst = max(sig_counts.values()) if sig_counts else 0
        if repeat >= 2 or worst >= 3 or error_streak >= 4:
            log(f"no progress (repeat={repeat}, same-signature={worst}, error-streak={error_streak}); nudging")
            messages.append({"role": "user", "content": prompts.NUDGE_REPEAT})
            llm.temperature = 0.4
            if repeat >= 4 or worst >= 5 or error_streak >= 8:
                log("stuck in a loop; leaving")
                break
        # Early exit: a valid deliverable was just written (saves a model round).
        if sp.deliverable and sp.kind in ("kv_report", "ctf", "exact"):
            mt = _mtime(sp.deliverable)
            if mt is not None and mt != st.deliverable_mtime:
                st.deliverable_mtime = mt
                ok, why = check_done(st, "")
                if ok:
                    log("deliverable written and verified; done without another round")
                    st.final_text = text
                    return
    st.final_text = final_text


# ---- finalisation ----------------------------------------------------------------------------

def finalize(st: State):
    if st.finalized:
        return
    st.finalized = True
    sp = st.spec
    if sp is None:
        return
    try:
        if sp.kind == "exact":
            for pth, content in (sp.exact_files or [(sp.deliverable, sp.exact_content)]):
                ok, _ = oracle.check_exact(pth, content)
                if not ok:
                    oracle.write_text(pth, content)
        elif sp.kind == "json_report" and sp.report_format == "text":
            ok, why = oracle.check_text_report(sp.deliverable)
            if not ok:
                findings = oracle.fallback_findings(st.brief.get("hotspots") or [], st.brief.get("routes") or [], sp.json_fields)
                findings += oracle.heuristic_findings(st.brief.get("routes") or [], st.workdir, sp.json_fields)[:6]
                if not findings:
                    findings = [{"title": "Manual review required", "severity": "informational", "category": "Informational",
                                 "location": str(st.workdir), "evidence": "Automated analysis could not complete.",
                                 "impact": "Unknown", "recommendation": "Review the application manually."}]
                oracle.write_text(sp.deliverable, oracle.findings_to_markdown(findings))
                log("wrote a text report from the scan")
            else:
                oracle.merge_text_report(sp.deliverable, sp.json_fields, st.brief.get("hotspots") or [],
                                         st.brief.get("routes") or [], log=log, workdir=st.workdir)
        elif sp.kind == "json_report":
            ok, why = oracle.check_json_report(sp.deliverable, sp.json_root, sp.json_fields)
            if not ok:
                log(f"report invalid or missing ({why}); building it from the scan")
                obj = oracle.load_json_lenient(st.final_text) if st.final_text else None
                report, findings = oracle.normalise_report(obj, sp.json_root, sp.json_fields) if obj is not None else (None, None)
                if report is None:
                    findings = oracle.fallback_findings(st.brief.get("hotspots") or [], st.brief.get("routes") or [], sp.json_fields)
                    if not findings:
                        findings = [{k: "" for k in sp.json_fields}]
                        findings[0].update({"title": "Manual review required", "severity": "informational",
                                            "category": "Informational",
                                            "location": str(st.workdir),
                                            "evidence": "Automated analysis could not complete.",
                                            "impact": "Unknown", "recommendation": "Review the application manually."})
                    report = {sp.json_root: findings}
                oracle.write_text(sp.deliverable, json.dumps(report, ensure_ascii=False, indent=2))
            oracle.merge_report(sp.deliverable, sp.json_root, sp.json_fields, st.brief.get("hotspots") or [],
                                st.brief.get("routes") or [], log=log, workdir=st.workdir)
        elif sp.kind == "kv_report":
            ok, why = oracle.check_kv(sp.deliverable, sp.keys)
            if not ok:
                found = oracle.salvage_kv_from_text(st.final_text or "", sp.keys)
                if found and not any(v.lower() in oracle.PLACEHOLDERS for v in found.values()):
                    oracle.write_kv(sp.deliverable, found, sp.keys)
                    log("wrote key=value answer salvaged from the reply")
                elif st.seed:
                    oracle.write_kv(sp.deliverable, st.seed, sp.keys)
                    log("wrote the preliminary automated answer as the deliverable")
                else:
                    partial = oracle.parse_kv_text(oracle.read_text(sp.deliverable), sp.keys) if Path(sp.deliverable).is_file() else {}
                    oracle.write_kv(sp.deliverable, {k: partial.get(k, "unknown") for k in sp.keys}, sp.keys)
                    log("wrote a placeholder key=value file (no verified answer)")
        elif sp.kind == "ctf":
            if sp.deliverable:
                ok, _ = oracle.check_flag_file(sp.deliverable, sp.flag_prefix)
                if not ok:
                    flag = oracle.extract_flag(st.final_text or "", sp.flag_prefix)
                    if not flag and st.seen_flags:
                        flag = st.seen_flags[-1]
                    if not flag and st.brief.get("flags"):
                        flag = st.brief["flags"][0][0]
                    if flag:
                        oracle.write_text(sp.deliverable, flag)
                        log(f"wrote best-effort flag: {flag}")
            flag = oracle.extract_flag(oracle.read_text(sp.deliverable) if sp.deliverable else "", sp.flag_prefix) or \
                oracle.extract_flag(st.final_text or "", sp.flag_prefix) or (st.seen_flags[-1] if st.seen_flags else None)
            if flag:
                print(f"FLAG: {flag}", flush=True)
        elif sp.kind == "code_fix":
            restore_broken_files(st)
        elif sp.kind == "generic" and sp.deliverable and not Path(sp.deliverable).is_file() and st.final_text:
            body = st.final_text.strip()
            body = re.sub(r"^DONE[:.\s-]*", "", body, flags=re.I).strip()
            if body:
                oracle.write_text(sp.deliverable, body)
                log("wrote the final reply as the deliverable")
    except Exception:  # noqa: BLE001
        traceback.print_exc()
    if st.final_text:
        print(f"[agent] final reply: {st.final_text[:1500]}", flush=True)


def restore_broken_files(st: State):
    """A file left with a syntax error guarantees a 0 (the app cannot start); restoring
    its original content at least keeps fixes made in other files alive."""
    for path, original in list(tools.ORIGINALS.items()):
        p = Path(path)
        if p.suffix != ".py" or not p.is_file():
            continue
        if not oracle.compile_errors([p]):
            continue
        try:
            if original is None:
                p.unlink()
                log(f"removed {path}: it was created during the run and does not compile")
            else:
                p.write_text(original, encoding="utf-8")
                log(f"restored {path}: the edited version does not compile")
        except OSError as exc:
            log(f"could not restore {path}: {exc}")


def telemetry(st: State):
    llm = st.llm
    elapsed = time.monotonic() - START_TS
    if llm is not None:
        log(f"done: kind={st.spec.kind if st.spec else '?'} calls={llm.calls} tokens={llm.tokens_used} "
            f"(in={llm.prompt_tokens} out={llm.completion_tokens}) elapsed={elapsed:.1f}s")
    else:
        log(f"done: kind={st.spec.kind if st.spec else '?'} calls=0 tokens=0 elapsed={elapsed:.1f}s")


# ---- entry -----------------------------------------------------------------------------------

def blind_fallback(st: State):
    """No statement reached us by any route: leave what each family would be graded on.

    This is pure insurance. Producing an unwanted extra file costs nothing, whereas
    leaving an empty disk because the statement never arrived costs the whole task."""
    wd = st.workdir
    made = []
    try:
        hotspots = brief.scan_hotspots(wd)
        routes = brief.routes(wd)
    except Exception:  # noqa: BLE001
        hotspots, routes = [], []
    if hotspots or routes:
        try:
            sp = specmod.Spec()
            sp.kind = "json_report"
            sp.json_root = "findings"
            sp.json_fields = list(specmod.DEFAULT_REPORT_FIELDS)
            sp.deliverable = str(wd / "security_report.json")
            report, notes = vulnreport.build(sp, wd, hotspots, routes)
            if notes["n"]:
                vulnreport.write(sp.deliverable, report)
                made.append(f"{sp.deliverable} ({notes['n']} findings)")
        except Exception as exc:  # noqa: BLE001
            log(f"blind report failed: {exc}")
    try:
        cands = brief.flag_candidates(wd)
        clean = [v for v, _src in cands if _clean_flag(v, "")]
        if len(clean) == 1:
            oracle.write_text(str(wd / "flag.txt"), clean[0])
            made.append(f"{wd / 'flag.txt'} ({clean[0]})")
    except Exception as exc:  # noqa: BLE001
        log(f"blind flag scan failed: {exc}")
    if made:
        log("no task statement was provided; wrote best-effort artifacts: " + "; ".join(made))
    else:
        log("no task statement was provided and nothing recognisable was found")
    return made


def run(st: State):
    sp = st.spec
    if not (st.instruction or "").strip():
        blind_fallback(st)
        return
    if sp.kind == "exact":
        all_ok = True
        for pth, content in (sp.exact_files or [(sp.deliverable, sp.exact_content)]):
            oracle.write_text(pth, content)
            ok, why = oracle.check_exact(pth, content)
            log(f"exact file {pth} written deterministically ({'ok' if ok else why})")
            all_ok = all_ok and ok
        if all_ok:
            return
    low_instr = st.instruction.lower()
    family = set(sp.keys) == forensic_seed.EXPECTED_KEYS or (
        sp.kind == "kv_report" and ("xff" in low_instr or "x-forwarded" in low_instr) and
        any(w in low_instr for w in ("exfil", "export", "jsonl", "audit")))
    if sp.kind == "kv_report" and family:
        root = sp.evidence_dir or str(st.workdir)
        try:
            seed = forensic_seed.solve(root, sp.keys, st.instruction)
        except Exception as exc:  # noqa: BLE001
            seed = None
            log(f"forensic seed failed: {exc}")
        if seed:
            st.seed = seed
            oracle.write_kv(sp.deliverable, seed, sp.keys)
            log("forensic seed written: " + ", ".join(f"{k}={v}" for k, v in seed.items() if not k.startswith("_")))
            # The statement of this task family names the exact record fields the solver
            # mirrors; when it does, the correlation is deterministic and the model would
            # only re-verify it at several thousand tokens per round.
            low = st.instruction.lower()
            mapped = forensic_seed.key_mapping(st.instruction, sp.keys)
            if (all(sig in low for sig in ("payload_logical_bytes", "identity.subject", "xff"))
                    or (len(mapped) >= max(2, len(sp.keys) - 2) and "xff" in low)) and \
                    not os.environ.get("LOCAL_AGENT_ALWAYS_MODEL"):
                ok, why = oracle.check_kv(sp.deliverable, sp.keys)
                if ok:
                    log("forensic task solved deterministically (0 tokens)")
                    return
    if sp.kind == "kv_report" and not st.seed and sp.deliverable:
        root = sp.evidence_dir or str(st.workdir)
        try:
            seed, conf = kv_seed.solve(root, sp.keys, st.instruction)
        except Exception as exc:  # noqa: BLE001
            seed, conf = None, {}
            log(f"profile seed failed: {exc}")
        if seed:
            if all(k in seed for k in sp.keys):
                st.seed, st.seed_conf = seed, conf
                oracle.write_kv(sp.deliverable, seed, sp.keys)
                log("profile seed written: " + ", ".join(f"{k}={seed[k]} ({conf.get(k)})" for k in sp.keys))
                # When every value matched the statement's own wording (high confidence) and
                # nothing violates the format/derivation checks, the answer is fully determined
                # by code — a very weak model can only corrupt it, so finish here (0 tokens).
                if not os.environ.get("LOCAL_AGENT_ALWAYS_MODEL") and all(conf.get(k) == "high" for k in sp.keys):
                    values = {k: seed[k] for k in sp.keys}
                    root_dir = sp.evidence_dir or str(st.workdir)
                    problems = oracle.kv_constraints(values, sp.keys, root_dir, st.instruction)
                    # Second, independent derivation: kv_verify re-reads the raw files with its
                    # own parsing and counting, so a bug in the profile pipeline cannot confirm
                    # itself. Only two agreeing implementations may skip the model.
                    disagree = kv_verify.verify(root_dir, sp.keys, st.instruction, values)
                    okk, _ = oracle.check_kv(sp.deliverable, sp.keys)
                    if okk and not problems and not disagree:
                        log("forensics solved deterministically: high confidence, constraints and an "
                            "independent recomputation all agree (0 tokens)")
                        return
                    if problems:
                        log("profile seed kept as a hint (constraint check flagged: " + "; ".join(problems)[:200] + ")")
                    if disagree:
                        log("profile seed kept as a hint (independent recomputation disagrees: "
                            + "; ".join(disagree)[:240] + ")")
            else:
                hints = {k: seed[k] for k in sp.keys if k in seed and conf.get(k) == "high"}
                if hints:
                    st.seed_partial = dict(hints, _detail=seed.get("_detail", ""))
                    log("partial profile seed (hints only): " + ", ".join(f"{k}={v}" for k, v in hints.items()))
    if sp.kind == "code_fix":
        st.snapshot = oracle.snapshot_tree(st.workdir)
        try:
            st.servers = oracle.find_servers(st.workdir)
        except Exception as exc:  # noqa: BLE001
            st.servers = []
            log(f"server discovery failed: {exc}")
        if st.servers:
            log("running servers: " + "; ".join(f"pid={s['pid']} ports={s['ports']} {' '.join(s['argv'])[:80]}" for s in st.servers))
        if not os.environ.get("AGENT_DISABLE_SQLFIX"):
            try:
                if mechanical_sql_fix(st):
                    return
            except Exception as exc:  # noqa: BLE001
                log(f"mechanical fix failed: {exc}")
    st.brief = brief.build(sp, st.workdir, log=log)
    log(f"briefing: {len(st.brief.get('text', ''))} chars, {len(st.brief.get('hotspots') or [])} hotspots, "
        f"{len(st.brief.get('routes') or [])} routes")
    if sp.kind == "json_report" and sp.deliverable:
        # A complete, code-derived report exists before the first model call, so the task
        # already has a valid graded artifact and the model only has to improve it.
        try:
            report, notes = vulnreport.build(sp, st.workdir, st.brief.get("hotspots"), st.brief.get("routes"))
            if notes["n"]:
                vulnreport.write(sp.deliverable, report)
                st.report_seeded = notes["n"]
                st.report_gaps = vulnreport.self_check(report, sp.json_root, st.instruction)
                log(f"draft report written: {notes['n']} findings ({notes['scan']} from the code scan, "
                    f"{notes['heuristic']} from the route map)"
                    + ("; own audit flags: " + "; ".join(st.report_gaps) if st.report_gaps else "; own audit: complete"))
                # When the scan proved real vulnerabilities (not just route-map guesses) and
                # the report passes its own audit, it is already the finished deliverable.
                # Letting a weak model rewrite several thousand tokens of JSON only risks a
                # truncated file and can exhaust the task's time budget.
                proven = [h for h in (st.brief.get("hotspots") or []) if h.get("severity") in ("critical", "high")]
                okj, whyj = oracle.check_json_report(sp.deliverable, sp.json_root, sp.json_fields)
                if proven and not st.report_gaps and okj and not os.environ.get("LOCAL_AGENT_ALWAYS_MODEL"):
                    log(f"report solved deterministically: {len(proven)} proven finding(s) from the code, "
                        "report complete and well-formed (0 tokens)")
                    return
                if not okj:
                    log(f"draft report did not validate ({whyj[:120]}); the model will rebuild it")
        except Exception as exc:  # noqa: BLE001
            log(f"draft report failed: {exc}")
    if sp.kind == "ctf" and sp.deliverable and not os.environ.get("LOCAL_AGENT_ALWAYS_MODEL"):
        try:
            gate_root = Path(sp.evidence_dir) if sp.evidence_dir else st.workdir
            flag, how = ctf_gate.solve(gate_root, sp.flag_prefix)
        except Exception as exc:  # noqa: BLE001
            flag, how = None, ""
            log(f"ctf gate solver failed: {exc}")
        if flag:
            oracle.write_text(sp.deliverable, flag)
            st.seen_flags.append(flag)
            log(f"ctf solved deterministically ({how}) (0 tokens)")
            return
    if sp.kind == "ctf" and sp.deliverable and st.brief.get("flags") and not os.environ.get("LOCAL_AGENT_ALWAYS_MODEL"):
        clean = [v for v, src in st.brief["flags"] if _clean_flag(v, sp.flag_prefix)]
        if len(clean) == 1:
            oracle.write_text(sp.deliverable, clean[0])
            st.seen_flags.append(clean[0])
            log(f"ctf solved deterministically: exactly one clean flag candidate {clean[0]} (0 tokens)")
            return
        if clean:
            # Insurance against being killed before finalize: a short task timeout
            # (120s for the trivial tier) can end the process at any moment, so the best
            # candidate goes to disk now and the model only refines it.
            oracle.write_text(sp.deliverable, clean[0])
            st.seen_flags.append(clean[0])
            log(f"{len(clean)} clean flag candidates; wrote {clean[0]} as insurance, the model may refine it")
    base_url, api_key, model = resolve_endpoint()
    if not base_url:
        log("no OPENAI_BASE_URL; skipping the model phase")
        return
    st.llm = LLM(base_url, api_key, model, st.deadline_ts, TOKEN_BUDGET, log=log)
    st.llm.discover_model()
    log(f"model={st.llm.model} endpoint={st.llm.url}")
    run_loop(st)
    if sp.kind == "kv_report":
        try:
            vote_kv(st)
        except Exception as exc:  # noqa: BLE001
            log(f"voting failed: {exc}")
    # A stalled first attempt on a short-transcript task gets one fresh start with a
    # different framing while there is still meaningful time left.
    if sp.kind in ("ctf", "kv_report", "generic") and st.llm.remaining() > 150 and not st.llm.exhausted(8000):
        ok, why = check_done(st, st.final_text)
        if not ok:
            recent = "\n".join(f"- {name}({args})" for name, args in st.call_history[-8:]) or "(nothing)"
            st.retry_note = prompts.RETRY_NOTE.format(calls=recent)
            st.llm.temperature = 0.5
            log(f"first attempt did not verify ({why[:120]}); retrying with a fresh transcript")
            run_loop(st)


def _kv_answer(st: State):
    sp = st.spec
    ok, _ = oracle.check_kv(sp.deliverable, sp.keys)
    if not ok:
        return None
    return oracle.parse_kv_text(oracle.read_text(sp.deliverable), sp.keys)


def _kv_score(st: State, values: dict) -> int:
    """Number of constraint/plausibility violations (lower is better)."""
    sp = st.spec
    n = 0
    try:
        if oracle.kv_plausibility(values, sp.evidence_dir or str(st.workdir)):
            n += 1
        n += len(oracle.kv_constraints(values, sp.keys, sp.evidence_dir or str(st.workdir), st.instruction))
    except Exception:  # noqa: BLE001
        pass
    return n


def vote_kv(st: State):
    """Independent re-analyses of a key=value task, combined per key by majority.

    A weak model's errors on a forensics question are usually specific to one reading of
    the statement; a second pass forced through a different method (one script that
    applies the definitions literally, with reasoning enabled when the server supports
    it) disagrees exactly on the keys that were wrong. Two matching answers stop early."""
    sp = st.spec
    llm = st.llm
    first = _kv_answer(st)
    if first is None or llm.remaining() < 240 or llm.exhausted(12000):
        return
    if os.environ.get("LOCAL_AGENT_NO_VOTE"):
        return
    if st.seed and all(str(st.seed.get(k, "")) == first.get(k, "") for k in sp.keys):
        log("kv vote: the answer equals the deterministic seed; no further attempts")
        return
    attempts = [first]
    seed_vote = None
    if st.seed and all(k in st.seed for k in sp.keys):
        seed_vote = {k: str(st.seed[k]) for k in sp.keys}
        diff = [k for k in sp.keys if seed_vote[k] != first.get(k, "")]
        log("kv vote: model and deterministic seed disagree on " + ", ".join(f"{k}: seed={seed_vote[k]} model={first.get(k)}" for k in diff))
    strategies = [
        (prompts.FORENSICS_SECOND_PASS, True, 0.2),
        ("Independent re-analysis with a checklist: for EACH key write 'key -> the task's defining words -> the exact "
         "log line -> value' in your reply, using the deterministic profiles in the context, then write the file.",
         False, 0.4),
    ]
    for note, think, temp in strategies:
        if llm.remaining() < 240 or llm.exhausted(12000):
            break
        st.retry_note = note
        saved_extra = dict(llm.extra)
        saved_max = llm.max_tokens
        if think and llm.extra:
            llm.extra = {"chat_template_kwargs": {"enable_thinking": True}}
            llm.max_tokens = max(llm.max_tokens, 8192)  # reasoning tokens count against the cap
        llm.temperature = temp
        st.kv_nudges = 0
        before = oracle.read_text(sp.deliverable)
        log(f"kv vote: independent attempt {len(attempts) + 1} (thinking={'on' if think and llm.extra else 'off'})")
        try:
            run_loop(st)
        finally:
            llm.extra = saved_extra
            llm.max_tokens = saved_max
        ans = _kv_answer(st)
        if ans is None or oracle.read_text(sp.deliverable) == before:
            log("kv vote: attempt produced no new answer")
            continue
        attempts.append(ans)
        if all(a == attempts[0] for a in attempts):
            log("kv vote: answers agree")
            break
        if seed_vote is not None and ans == seed_vote:
            log("kv vote: the second attempt agrees with the deterministic seed")
            break
        if len(attempts) >= 3:
            break
    voters = attempts + ([seed_vote] if seed_vote is not None else [])
    final = {}
    for k in sp.keys:
        vals = [a.get(k, "").strip() for a in voters if a.get(k, "").strip()]
        counts = {}
        for v in vals:
            counts[v] = counts.get(v, 0) + 1
        best = max(counts.items(), key=lambda kv: kv[1]) if counts else ("", 0)
        if best[1] >= 2 or len(counts) == 1:
            final[k] = best[0]
        else:
            # no majority: prefer the value that violates no rule; then a seed value the
            # statement defined literally (a weak model miscounts more often than code
            # does); then the first attempt's value
            def _rank(v):
                seeded = seed_vote is not None and v == seed_vote.get(k) and st.seed_conf.get(k) == "high"
                return (_kv_score(st, {k: v}), 0 if seeded else 1, vals.index(v))
            ranked = sorted(counts.keys(), key=_rank)
            final[k] = ranked[0]
    if final != attempts[0]:
        log("kv vote: per-key result differs from the first attempt: " +
            ", ".join(f"{k}: {attempts[0].get(k)} -> {final[k]}" for k in sp.keys if attempts[0].get(k) != final[k]))
    else:
        log("kv vote: keeping the first attempt's answer")
    oracle.write_kv(sp.deliverable, final, sp.keys)
    st.final_text = st.final_text or "DONE"


# ---- how the task reaches us ----------------------------------------------------------
# A runner that hands the statement over by some route other than argv would otherwise
# fail every task at once, so each plausible route is tried before giving up.

_INSTR_ENV = ("LOCAL_AGENT_INSTRUCTION", "AGENT_INSTRUCTION", "TASK_INSTRUCTION", "INSTRUCTION",
              "TASK_PROMPT", "PROMPT", "TASK", "TASK_DESCRIPTION", "HARBOR_TASK", "AGENT_TASK",
              "TASK_TEXT", "QUERY")
_INSTR_FILES = ("instruction.md", "INSTRUCTION.md", "task.md", "TASK.md", "prompt.md", "PROMPT.md",
                "instructions.txt", "instruction.txt", "task.txt", "README_TASK.md")
_INSTR_DIRS = ("/app", "/task", "/tasks", "/workspace", "/opt/harbor", "/opt/harbor/task", ".")


def _read_stdin_instruction(timeout: float = 2.0) -> str:
    """The statement piped in, if any. Never blocks a runner that leaves stdin open."""
    try:
        if sys.stdin is None or sys.stdin.closed or sys.stdin.isatty():
            return ""
    except Exception:  # noqa: BLE001
        return ""
    try:
        import select
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if not ready:
            return ""
        return sys.stdin.read()[:200000].strip()
    except Exception:  # noqa: BLE001
        return ""


def _instruction_from_env() -> str:
    for name in _INSTR_ENV:
        val = (os.environ.get(name) or "").strip()
        if len(val) > 20:
            return val
    return ""


def _instruction_from_files() -> str:
    for d in _INSTR_DIRS:
        for name in _INSTR_FILES:
            try:
                p = Path(d) / name
                if p.is_file() and p.stat().st_size < 200000:
                    text = p.read_text(encoding="utf-8", errors="replace").strip()
                    if len(text) > 20:
                        return text
            except OSError:
                continue
    return ""


def obtain_instruction(argv) -> tuple:
    """(instruction, where it came from)."""
    joined = " ".join(a for a in argv[1:]).strip()
    if len(joined) > 20:
        return joined, "argv"
    piped = _read_stdin_instruction()
    if len(piped) > 20:
        return piped, "stdin"
    env = _instruction_from_env()
    if env:
        return env, "environment"
    filed = _instruction_from_files()
    if filed:
        return filed, "task file"
    return joined, "argv (empty)"


# Endpoint settings under every spelling a runner might use.
_BASE_ENV = ("OPENAI_BASE_URL", "OPENAI_API_BASE", "OPENAI_BASE", "LOCAL_AGENT_BASE_URL", "LLM_BASE_URL",
             "MODEL_BASE_URL", "OPENAI_ENDPOINT", "AZURE_OPENAI_ENDPOINT", "API_BASE", "BASE_URL")
_KEY_ENV = ("OPENAI_API_KEY", "LOCAL_AGENT_API_KEY", "LLM_API_KEY", "OPENAI_KEY", "API_KEY", "MODEL_API_KEY")
_MODEL_ENV = ("LOCAL_AGENT_MODEL", "OPENAI_MODEL", "LLM_MODEL", "MODEL_NAME", "MODEL")
_PROBE_URLS = ("http://127.0.0.1:8000/v1", "http://127.0.0.1:8080/v1", "http://localhost:8000/v1",
               "http://127.0.0.1:1234/v1", "http://127.0.0.1:11434/v1", "http://127.0.0.1:5000/v1")


def _first_env(names):
    for n in names:
        v = (os.environ.get(n) or "").strip()
        if v:
            return v
    return ""


def _probe_endpoint():
    """Find a local OpenAI-compatible server when no endpoint was configured."""
    import urllib.request
    for url in _PROBE_URLS:
        try:
            req = urllib.request.Request(url.rstrip("/") + "/models", headers={"Authorization": "Bearer local"})
            with urllib.request.urlopen(req, timeout=2) as resp:
                if resp.status == 200:
                    return url
        except Exception:  # noqa: BLE001
            continue
    return ""


def resolve_endpoint():
    """(base_url, api_key, model) from the environment, probing as a last resort."""
    base = _first_env(_BASE_ENV)
    key = _first_env(_KEY_ENV) or "local"
    model = _first_env(_MODEL_ENV)
    if not base:
        base = _probe_endpoint()
        if base:
            log(f"no endpoint configured; found a local server at {base}")
    return base, key, model


def main(argv) -> int:
    instruction, source = obtain_instruction(argv)
    st = State()
    st.instruction = instruction
    st.workdir = pick_workdir()
    if source != "argv":
        log(f"task statement read from {source} ({len(instruction)} chars)")
    try:
        st.spec = specmod.triage(instruction, st.workdir)
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        st.spec = specmod.Spec()
    log(f"workdir={st.workdir} {st.spec.describe()}")

    def on_alarm(signum, frame):
        log("hard deadline reached; finalising")
        try:
            finalize(st)
            telemetry(st)
        finally:
            sys.stdout.flush()
            os._exit(0)

    try:
        signal.signal(signal.SIGALRM, on_alarm)
        signal.alarm(int(SOFT_DEADLINE_SEC + HARD_GRACE_SEC))
    except Exception:  # noqa: BLE001
        pass
    try:
        run(st)
    except Exception:  # noqa: BLE001
        traceback.print_exc()
    finally:
        try:
            finalize(st)
        except Exception:  # noqa: BLE001
            traceback.print_exc()
        try:
            telemetry(st)
        except Exception:  # noqa: BLE001
            pass
        sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
